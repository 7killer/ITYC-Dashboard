# ITYC-Dashboard
 <div class="row  pb-3">
                         <p>
                            Code is provide as it ! Fell free to re use !
                          </p>
                          <p>
                            La navigation sur Virtual Regatta , comme dans le réel dépend de nombreux facteurs (vitesse et direction du vent, variation dans le temps, polaires du bateau...).
                          </p>
                          <p>
                            Pour vous épauler au quotidien, ITYC vous propose une dashboard munie de fonctionnalités avancées, elle vous permettra de visualiser les paramètres météo que traverse votre bateau ou d obtenir des infos informations plus poussées concernant votre bateau.
                          <p>
                            Grâce à l onglet carte, visualisez en un coup d'oeil la position de vos adversaires, comparez vos routages ou évaluez de votre distance à la cotes de manière lisible.
                            L'onglet graphique vous permettera quand à lui de visualiser les variations des paramètres principaux sous forme graphique offrant une meilleure visibilité.
                            Découvrez ci dessous les nombreuses possibilités offertes par la dashboard ITYC ci dessous.
                          </p>
                          <p class="row font-weight-bold">
                            L'extension ITYC vous est fournie en l'état et ne vous fournir que des INDICATIONS.
                          </p>
                          <p class="row font-weight-bold">
                            L'extension ITYC est compatible avec les navigateurs Chrome, Edge et Opera. Elle ne fonctionne pas sous Firefox!
                          </p>
                          <p class="row font-weight-bold">
                            L'extension ITYC ne fonctionne que sur la page du jeu virtual regatta offshore ( toutes langues supportées) et leurs iframes associées!
                          </p>
                          Consultez <a href="https://www.ityc.fr/aide_dash.html">l'aide en ligne</a> pour plus de détais
                        </div>
                        
                        
