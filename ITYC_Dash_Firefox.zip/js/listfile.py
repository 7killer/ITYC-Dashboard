import os
import json

def generate_js_file(directory, output_file):
    try:
        # Liste pour stocker les noms de fichiers et extensions
        file_data = []

        # Parcourir le répertoire
        for root, _, files in os.walk(directory):
            for file in files:
                name, extension = os.path.splitext(file)
                file_data.append(name)

        # Convertir en tableau JavaScript
        js_content = f"const files = {json.dumps(file_data, indent=4)};"

        # Enregistrer dans un fichier .js
        with open(output_file, "w") as f:
            f.write(js_content)

        print(f"Fichier JavaScript généré: {output_file}")

    except Exception as e:
        print(f"Erreur: {e}")

# Exemple d'utilisation
directory = "C:/virtual regatta/git/ITYC-Dashboard-Firefox/cachedTiles"  # Chemin du répertoire à analyser
output_file = "C:/virtual regatta/git/ITYC-Dashboard-Firefox/output.js"
generate_js_file(directory, output_file)